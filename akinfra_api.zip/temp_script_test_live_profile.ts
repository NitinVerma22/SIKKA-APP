import jwt from 'jsonwebtoken';
import https from 'https';

async function main() {
  const userId = "051b67f0-ef3c-4207-acd0-6b17333178ab";
  const JWT_SECRET = "super-secret-sikkaplay-key";

  // Generate JWT token
  const token = jwt.sign({ userId }, JWT_SECRET);
  console.log(`Generated Token: ${token}`);

  const options = {
    hostname: 'sikkaplay-backend-834810172223.asia-south1.run.app',
    path: '/api/user/profile',
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`
    }
  };

  const req = https.request(options, (res) => {
    let data = '';
    console.log(`STATUS: ${res.statusCode}`);
    res.on('data', (chunk) => {
      data += chunk;
    });
    res.on('end', () => {
      try {
        const parsed = JSON.parse(data);
        console.log("LIVE BACKEND RESPONSE:");
        console.log(JSON.stringify(parsed, null, 2));
      } catch (e) {
        console.log("Raw response data:", data);
      }
    });
  });

  req.on('error', (e) => {
    console.error(`Problem with request: ${e.message}`);
  });

  req.end();
}

main();
